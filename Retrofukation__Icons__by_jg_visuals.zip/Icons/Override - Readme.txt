The override folder is a means of installing the icons using the tango patcher by vertigosity.

http://vertigosity.deviantart.com/art/Tango-Patcher-2600-8-06-27940418

Simply place the 'override' folder of choice on your desktop & then install the patcher.  I recommend the tangerine variation, as not all of the icons/system files have been skinned with the 'retrofukation' icons.
Also skip the boot options...i.e. logon & boot menu.

There are elements which are obviously not skinned and will have remnants of the Tango patcher remaining.

Thanks to vertigosity for the amazing work he did with the patcher.

CONTACT:

Jamie
-jg-

jg.visuals@gmail.com

http://customize.org/jg-visuals

http://jg-visuals.deviantart.com/